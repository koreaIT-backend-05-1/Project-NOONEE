package com.project.noonee.domain.product;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductRepository {
	public List<Product> getProductList(Map<String, Object> map) throws Exception;
}
