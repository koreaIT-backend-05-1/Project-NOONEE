package com.project.noonee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NooneeApplication {

	public static void main(String[] args) {
		SpringApplication.run(NooneeApplication.class, args);
	}

}
