package com.project.noonee.service.product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.project.noonee.domain.product.ProductRepository;
import com.project.noonee.web.dto.product.ProductRespDto;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {
	
	private final ProductRepository productRepository;

	@Override
	public List<ProductRespDto> getProductList(int productCategory, String productDetailsCategory) throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("product_category", productCategory);
		map.put("product_details_category", productDetailsCategory);
		
		List<ProductRespDto> list = new ArrayList<ProductRespDto>();
		
		productRepository.getProductList(map).forEach(product -> {
			list.add(product.toListDto());
		});
		return list;
	}
	
	
}
