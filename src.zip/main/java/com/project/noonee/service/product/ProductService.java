package com.project.noonee.service.product;

import java.util.List;

import com.project.noonee.web.dto.product.ProductRespDto;

public interface ProductService {
	public List<ProductRespDto> getProductList(int productCategory, String productDetailsCategory) throws Exception;
}
