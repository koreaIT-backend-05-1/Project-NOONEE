package com.project.noonee.web.dto.inquiry;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class GetInquiryRepDto {
	private int noticeCode;
	private String noticeTitle;
	private String username;
	private String createDate;
	private int noticeCount;
	private int totalNoticeCoint;
}
