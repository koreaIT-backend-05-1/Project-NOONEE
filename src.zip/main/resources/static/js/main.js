const mainBtn = document.querySelectorAll(".img-btn button");
const marketPlace = document.querySelector(".market-place-text");
const img = document.querySelector(".img");
const directionsBtn = document.querySelector(".directions");

let flag = [true, false, false, false]
let mainText = ["Edizione NOONEE - HANNAM MAIN", "b", "c", "d"];
let mainImg = ["/static/img/brandPage/page3-4.jpg", "/static/img/brandPage/page3-5.jpg",
 "/static/img/brandPage/page3-6.jpg", "/static/img/brandPage/page3-7.jpg"];

change();

for(let i = 0; i < mainBtn.length; i++) {
    mainBtn[i].onmousedown = () => {
		for(let j = 0; j < flag.length; j++) {
			flag[j] = false;
		}
		marketPlace.textContent = mainText[i];
		img.src = mainImg[i];
        flag[i] = true;
        change();
    }
}

function change() {
	for(let i = 0; i < flag.length; i++) {
		mainBtn[i].style.backgroundColor ="#ffffff00";
	}
	mainBtn[flag.indexOf(true)].style.backgroundColor ="#ffffff";
}

directionsBtn.onclick = () => {
	location.href = "/shopinfo";
}







