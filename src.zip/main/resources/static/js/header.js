const logo = document.querySelector(".logo-img");
const navMenu = document.querySelectorAll(".nav-menu");
const subMenu = document.querySelectorAll(".nav-sub");
const visibleDiv = document.querySelectorAll(".nav-menu div");

for(let i = 0; i < navMenu.length; i++) {
    navMenu[i].onmouseover = () => {
        subMenu[i].classList.remove("visible");
        visibleDiv[i].classList.add("fadein");
    }

    navMenu[i].onmouseout = () => {
        visibleDiv[i].classList.add("visible");
        visibleDiv[i].classList.remove("fadein");
    }

    subMenu[i].onmouseover = () => {
        visibleDiv[i].classList.remove("visible");
        visibleDiv[i].classList.add("fadein");
    }

    subMenu[i].onmouseout = () => {
        visibleDiv[i].classList.add("visible");
        visibleDiv[i].classList.remove("fadein");
    }

}


logo.onclick = () => {
	location.href = "/auth/main";
}

function getPrincipal() {
	let user = null;
	
	$.ajax({
		async: false,
		type: "get",
		url: "/api/v1/auth/principal",
		dataType: "json",
		success: (response) => {
			user = response.data;
		},
		error: (error) => {
			console.log(error);
		}
	});
	
	return user;
}

function loadHeader(user) {
	const authItems = document.querySelector(".auth-items");
	
	if(user == null) {
		authItems.innerHTML = `
		<button type="button" class="sub-menu-btn signin">LOGIN</button>
        <button type="button" class="sub-menu-btn signup">JOIN</button>
        `;
        
        const signin = document.querySelector(".signin");
        const signup = document.querySelector(".signup");
        
        signin.onclick = () => {
			location.href = "/auth/signin";
		}
		
		signup.onclick = () => {
			location.href = "/auth/signupdetail";
		}
	}else {
		authItems.innerHTML = `
        <button type="button" class="sub-menu-btn logout">LOGOUT</button>
		<button type="button" class="sub-menu-btn mypage">MY</button>
        `;
        
        const logout = document.querySelector(".logout");
        const mypage = document.querySelector(".mypage");
        
        logout.onclick = () => {
			location.replace("/logout");
		}
		
		mypage.onclick = () => {
			location.href = "/user/mypage";
		}
	}
}

let user = getPrincipal();

loadHeader(user);

function getUser() {
	return user;
}

const search = document.querySelector(".search");
const modalClose = document.querySelector(".modal-close");
const searchModal = document.querySelector(".search-modal");

search.onclick = () => {
	
	searchModal.classList.toggle("modal-visible");
}

modalClose.onclick = () => {
	searchModal.classList.toggle("modal-visible");
}

console.log(user);


