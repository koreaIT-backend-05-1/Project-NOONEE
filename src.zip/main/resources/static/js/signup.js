const signupBtn = document.querySelector(".signup-btn");

signupBtn.onclick = () => {
	location.href = "/auth/consent";
}